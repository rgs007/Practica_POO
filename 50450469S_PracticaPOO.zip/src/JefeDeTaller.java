
/**
 * Write a description of class JefeDeTaller here.
 * 
 * @author Ricardo García
 * @version 15/05/2017
 */
public class JefeDeTaller extends Mecanico
{
   
    /**
     * Constructor for objects of class JefeDeTaller
     */
    public JefeDeTaller(String nombre, String telefono)
    {
        super(nombre, telefono);
    }

   
}
