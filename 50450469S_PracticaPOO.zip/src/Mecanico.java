
/**
 * Write a description of class Mecanico here.
 * 
 * @author Ricardo García
 * @version 15/05/2017
 */
public class Mecanico extends Usuario
{
    /**
     * Constructor for objects of class Mecanico
     */
    public Mecanico(String nombre, String telefono)
    {
        super(nombre, telefono);
    }

}
