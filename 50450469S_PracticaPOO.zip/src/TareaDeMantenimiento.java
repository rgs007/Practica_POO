
/**
 * Write a description of class TareasDeMantenimento here.
 *
 * @author Ricardo García
 * @version 15/05/2017
 */
public class TareaDeMantenimiento
{
   private String description = "";
    public TareaDeMantenimiento(String descripcion)
    {
        this.description = description;
    }
    
    public String getDescription()
    {
        return description;
    }
   
}
