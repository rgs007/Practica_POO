
/**
 * Write a description of class Comercial here.
 * 
 * @author Ricardo García
 * @version 15/05/2017
 */
public class Comercial extends Usuario
{
   
    /**
     * Constructor for objects of class Comercial
     */
    public Comercial(String nombre, String telefono)
    {
        super(nombre, telefono);
    }
    
}
