
/**
 * Enumeration class TipoCombustible - write a description of the enum class here
 *
 * @author Ricardo García
 * @version 15/05/2017
 */
public enum TipoCombustible
{
    GASOLINA, DIESEL, ELECTRICO
}
