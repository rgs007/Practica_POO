
/**
 * Enumeration class TipoDeVehiculo - write a description of the enum class here
 * 
 * @author Ricardo García
 * @version 15/05/2017
 */
public enum TipoDeVehiculo
{
    COCHE, MOTO, COCHESP, MOTOSP
}
