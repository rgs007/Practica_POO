
/**
 * Write a description of class CocheDeServicioPublico here.
 *
 * @author Ricardo García
 * @version 15/05/2017
 */
public class CocheDeServicioPublico extends Coche
{
    
    /**
     * Constructor for objects of class CocheDeServicioPublico
     */
    public CocheDeServicioPublico(String matricula, String modelo, TipoCombustible tipoCombustible)
    {
        super(matricula, modelo, tipoCombustible);
    }

}
