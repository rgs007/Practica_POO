
/**
 * Enumeration class EstadoRevision - Estados por los que pasa la revisión
 * 
 * @author Ricardo García
 * @version 15/05/2017
 */
public enum EstadoRevision
{
    PENDIENTE, COMPLETADA, PAUSADA
}
